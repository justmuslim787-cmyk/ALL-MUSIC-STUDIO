import json
import tempfile
import unittest
import wave
from pathlib import Path

from app.audio.audio_engine import AudioEngine
from app.core.studio_session import StudioSession


class FakeBackend:
    def __init__(self):
        self.loaded = None
        self.state = "idle"
        self.volume = 1.0

    def load(self, path):
        self.loaded = str(path)

    def play(self):
        self.state = "playing"

    def pause(self):
        self.state = "paused"

    def resume(self):
        self.state = "playing"

    def stop(self):
        self.state = "stopped"

    def set_volume(self, value):
        self.volume = value


def make_wav(path, samples=(1000, -1000, 500, -500), rate=8000):
    import struct

    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        wav.writeframes(struct.pack("<" + "h" * len(samples), *samples))


class StudioSessionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.music = self.root / "song.wav"
        make_wav(self.music)
        self.backend = FakeBackend()
        self.session = StudioSession(
            audio_engine=AudioEngine(backend=self.backend)
        )

    def test_select_and_playback_controls(self):
        self.session.select_file(self.music)
        self.assertEqual(self.backend.loaded, str(self.music.resolve()))

        self.session.play()
        self.assertEqual(self.session.audio.status, "playing")

        self.session.pause()
        self.assertEqual(self.session.audio.status, "paused")

        self.session.resume()
        self.assertEqual(self.session.audio.status, "playing")

        self.session.stop()
        self.assertEqual(self.session.audio.status, "stopped")

    def test_volume_control(self):
        self.assertEqual(self.session.set_volume(0.4), 0.4)
        self.assertEqual(self.backend.volume, 0.4)

        with self.assertRaises(ValueError):
            self.session.set_volume(2)

    def test_missing_and_unsupported_files(self):
        with self.assertRaises(FileNotFoundError):
            self.session.select_file(self.root / "missing.wav")

        bad = self.root / "notes.txt"
        bad.write_text("not audio", encoding="utf-8")

        with self.assertRaises(ValueError):
            self.session.select_file(bad)

    def test_mix_project_save_and_load(self):
        self.session.add_mix_track(str(self.music), volume=0.7, pan=-0.2)
        project_file = self.root / "test.ams.json"

        self.session.save_project(project_file)

        data = json.loads(project_file.read_text(encoding="utf-8"))
        self.assertEqual(data["format"], "all_music_studio_mix")
        self.assertEqual(len(data["tracks"]), 1)

        loaded = self.session.load_project(project_file)
        self.assertEqual(loaded["track_count"], 1)
        self.assertAlmostEqual(loaded["tracks"][0]["volume"], 0.7)

    def test_mix_track_update_and_remove(self):
        self.session.add_mix_track(str(self.music))
        self.session.update_mix_track(0, volume=0.5, mute=True)

        track = self.session.project.tracks[0]
        self.assertEqual(track["volume"], 0.5)
        self.assertTrue(track["mute"])

        removed = self.session.remove_mix_track(0)
        self.assertTrue(removed["mute"])
        self.assertEqual(len(self.session.project.tracks), 0)

    def test_export_wav(self):
        self.session.add_mix_track(str(self.music))
        output = self.root / "exports" / "result.wav"

        result = self.session.export_wav(output)

        self.assertTrue(output.is_file())
        self.assertEqual(result["channels"], 2)
        self.assertEqual(result["sample_rate"], 8000)
        self.assertEqual(result["frames"], 4)

    def test_export_requires_a_track(self):
        with self.assertRaises(ValueError):
            self.session.export_wav(self.root / "empty.wav")


if __name__ == "__main__":
    unittest.main()
