import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.ui.studio_app import list_audio_files, import_audio_file


class StudioUITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.music = self.root / "music"
        self.music.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def test_list_supported_audio(self):
        (self.music / "song.wav").write_bytes(b"wav")
        (self.music / "notes.txt").write_text("not audio")
        with patch("app.ui.studio_app.MUSIC_DIR", self.music):
            self.assertEqual(
                [p.name for p in list_audio_files()],
                ["song.wav"],
            )

    def test_import_audio(self):
        source = self.root / "source.wav"
        source.write_bytes(b"audio")
        with patch("app.ui.studio_app.MUSIC_DIR", self.music):
            destination = import_audio_file(source)
        self.assertTrue(destination.exists())
        self.assertEqual(destination.read_bytes(), b"audio")

    def test_duplicate_import_gets_new_name(self):
        source = self.root / "song.wav"
        source.write_bytes(b"first")
        (self.music / "song.wav").write_bytes(b"existing")
        with patch("app.ui.studio_app.MUSIC_DIR", self.music):
            destination = import_audio_file(source)
        self.assertEqual(destination.name, "song_2.wav")

    def test_reject_unsupported_extension(self):
        source = self.root / "document.txt"
        source.write_text("hello")
        with patch("app.ui.studio_app.MUSIC_DIR", self.music):
            with self.assertRaises(ValueError):
                import_audio_file(source)


if __name__ == "__main__":
    unittest.main()
