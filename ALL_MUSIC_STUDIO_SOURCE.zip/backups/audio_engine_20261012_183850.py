"""ALL MUSIC STUDIO - Audio Playback Engine."""

from pathlib import Path


SUPPORTED_FORMATS = {".wav", ".mp3", ".ogg", ".flac"}


class PygameAudioBackend:
    """Optional real audio playback backend."""

    def __init__(self):
        import pygame
        self.pygame = pygame
        if not pygame.mixer.get_init():
            pygame.mixer.init()

    def load(self, path):
        self.pygame.mixer.music.load(str(path))

    def play(self):
        self.pygame.mixer.music.play()

    def pause(self):
        self.pygame.mixer.music.pause()

    def resume(self):
        self.pygame.mixer.music.unpause()

    def stop(self):
        self.pygame.mixer.music.stop()

    def set_volume(self, volume):
        self.pygame.mixer.music.set_volume(volume)


class AudioEngine:
    """Load and control audio through a playback backend."""

    def __init__(self, backend=None):
        self.backend = backend
        self.file_path = None
        self.status = "idle"
        self.volume = 1.0
        self.last_error = None

        if self.backend is None:
            try:
                self.backend = PygameAudioBackend()
            except Exception as error:
                self.last_error = str(error)

    @property
    def available(self):
        return self.backend is not None

    def load_file(self, filename):
        path = Path(filename).expanduser()

        if not path.is_file():
            raise FileNotFoundError(f"Audio file not found: {path}")

        if path.suffix.lower() not in SUPPORTED_FORMATS:
            raise ValueError(
                "Unsupported audio format. Use WAV, MP3, OGG or FLAC."
            )

        if self.backend is None:
            raise RuntimeError(
                "Audio playback backend is unavailable. "
                "Install pygame in the environment where the studio runs."
            )

        self.backend.load(path)
        self.file_path = path.resolve()
        self.status = "loaded"
        return self.file_path

    def play(self):
        self._require_loaded()
        self.backend.play()
        self.status = "playing"

    def pause(self):
        self._require_loaded()
        if self.status == "playing":
            self.backend.pause()
            self.status = "paused"

    def resume(self):
        self._require_loaded()
        if self.status == "paused":
            self.backend.resume()
            self.status = "playing"
        elif self.status in {"loaded", "stopped"}:
            self.play()

    def stop(self):
        self._require_loaded()
        self.backend.stop()
        self.status = "stopped"

    def set_volume(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Volume must be a number.")

        if not 0.0 <= value <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0.")

        self.volume = float(value)

        if self.backend is not None:
            self.backend.set_volume(self.volume)

        return self.volume

    def _require_loaded(self):
        if self.file_path is None:
            raise RuntimeError("Load an audio file first.")

        if self.backend is None:
            raise RuntimeError(
                "Audio playback backend is unavailable."
            )

    def info(self):
        return {
            "file": str(self.file_path) if self.file_path else None,
            "status": self.status,
            "volume": self.volume,
            "playback_available": self.available,
        }
