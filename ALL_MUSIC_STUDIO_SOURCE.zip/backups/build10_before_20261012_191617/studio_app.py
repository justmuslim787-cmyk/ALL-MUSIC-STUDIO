"""Responsive Kivy GUI for All Music Studio.

Runs on supported desktop platforms and can be packaged for Android.
The GUI connects to the existing library and mix-project modules.
"""

from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]
MUSIC_DIR = ROOT / "assets" / "music"
PROJECT_DIR = ROOT / "projects"
SUPPORTED = {".wav", ".mp3", ".ogg", ".flac"}


def list_audio_files():
    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(
        p for p in MUSIC_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in SUPPORTED
    )


def import_audio_file(source):
    source = Path(source).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(str(source))
    if source.suffix.lower() not in SUPPORTED:
        raise ValueError("Unsupported audio format")

    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    destination = MUSIC_DIR / source.name

    if source == destination.resolve():
        return destination

    stem, suffix = source.stem, source.suffix
    number = 2
    while destination.exists():
        destination = MUSIC_DIR / f"{stem}_{number}{suffix}"
        number += 1

    shutil.copy2(source, destination)
    return destination


def launch():
    try:
        from kivy.app import App
        from kivy.metrics import dp
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        from kivy.uix.label import Label
        from kivy.uix.scrollview import ScrollView
        from kivy.uix.slider import Slider
        from kivy.uix.textinput import TextInput
    except ImportError as exc:
        raise RuntimeError(
            "Kivy is not installed. Install it in a supported environment "
            "before launching the graphical interface."
        ) from exc

    class StudioApp(App):
        def build(self):
            self.title = "ALL MUSIC STUDIO"
            self.current_audio = None

            root = BoxLayout(
                orientation="vertical",
                padding=dp(12),
                spacing=dp(8),
            )

            root.add_widget(Label(
                text="[b]ALL MUSIC STUDIO[/b]",
                markup=True,
                font_size="24sp",
                size_hint_y=None,
                height=dp(48),
            ))

            root.add_widget(Label(
                text="MOBILE + PC  |  MUSIC LIBRARY + MIXER",
                size_hint_y=None,
                height=dp(28),
            ))

            self.status = Label(
                text="Ready — import or select a music file",
                size_hint_y=None,
                height=dp(35),
            )
            root.add_widget(self.status)

            controls = BoxLayout(
                size_hint_y=None,
                height=dp(48),
                spacing=dp(6),
            )

            refresh = Button(text="Refresh Library")
            refresh.bind(on_release=lambda *_: self.refresh_library())
            controls.add_widget(refresh)

            import_btn = Button(text="Import File")
            import_btn.bind(on_release=lambda *_: self.show_import_help())
            controls.add_widget(import_btn)
            root.add_widget(controls)

            self.library = BoxLayout(
                orientation="vertical",
                spacing=dp(5),
                size_hint_y=None,
            )
            self.library.bind(minimum_height=self.library.setter("height"))

            scroll = ScrollView()
            scroll.add_widget(self.library)
            root.add_widget(scroll)

            mixer_title = Label(
                text="[b]TRACK MIXER FOUNDATION[/b]",
                markup=True,
                size_hint_y=None,
                height=dp(32),
            )
            root.add_widget(mixer_title)

            self.volume = Slider(
                min=0,
                max=1,
                value=1,
                size_hint_y=None,
                height=dp(40),
            )
            root.add_widget(self.volume)

            buttons = BoxLayout(
                size_hint_y=None,
                height=dp(48),
                spacing=dp(6),
            )
            for name in ("Play", "Pause", "Stop", "Save Project", "Export WAV"):
                button = Button(text=name)
                button.bind(on_release=self.action_message)
                buttons.add_widget(button)
            root.add_widget(buttons)

            self.refresh_library()
            return root

        def refresh_library(self):
            self.library.clear_widgets()
            files = list_audio_files()

            if not files:
                self.library.add_widget(Label(
                    text="No audio files yet. Add WAV, MP3, OGG or FLAC files "
                         "to assets/music.",
                    size_hint_y=None,
                    height=dp(70),
                ))
                return

            for path in files:
                row = Button(
                    text=path.name,
                    size_hint_y=None,
                    height=dp(48),
                )
                row.bind(on_release=lambda _btn, p=path: self.select_audio(p))
                self.library.add_widget(row)

        def select_audio(self, path):
            self.current_audio = path
            self.status.text = "Selected: " + path.name

        def show_import_help(self):
            self.status.text = (
                "Place audio files in assets/music, then tap Refresh Library. "
                "Native file-picker integration is a later step."
            )

        def action_message(self, button):
            name = button.text
            if name == "Play":
                self.status.text = (
                    "Selected file: " + self.current_audio.name
                    if self.current_audio else "Select a track first"
                )
            elif name == "Pause":
                self.status.text = "Pause: playback integration pending"
            elif name == "Stop":
                self.status.text = "Stop: playback integration pending"
            elif name == "Save Project":
                self.status.text = (
                    "Project saving is available through the existing "
                    "MixProject Python API; GUI integration pending"
                )
            elif name == "Export WAV":
                self.status.text = (
                    "WAV export uses the existing offline mix engine; "
                    "GUI integration pending"
                )

    StudioApp().run()


if __name__ == "__main__":
    launch()
