# ALL MUSIC STUDIO

## Audio Library
Supports WAV, MP3, OGG and FLAC files.
Can scan folders, search filenames and import audio files.

## Audio Mixer
Each logical channel has:
- Volume: 0.0 to 1.0
- Pan: -1.0 to 1.0
- Mute
- Solo

Note: True independent simultaneous audio playback is not
implemented yet. The current Termux media player uses a
shared Android media session.
