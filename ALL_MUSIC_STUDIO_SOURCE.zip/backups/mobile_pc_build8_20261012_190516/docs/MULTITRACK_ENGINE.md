# ALL MUSIC STUDIO — Multi-Track Engine

The first offline mixer supports uncompressed 16-bit PCM WAV files
in mono or stereo, provided all tracks use the same sample rate.

Track settings:
- volume: 0.0 to 1.0
- pan: -1.0 to 1.0
- mute: true or false
- solo: true or false

Example:
    from app.audio.multitrack_engine import MultiTrackEngine

    engine = MultiTrackEngine()
    result = engine.render([
        {"path": "assets/music/track1.wav", "volume": 0.8},
        {"path": "assets/music/track2.wav", "volume": 0.5},
    ], "assets/music/mix_output.wav")
    print(result)

This is offline mixing, not yet a real-time multitrack playback UI.
MP3/OGG/FLAC decoding, resampling, effects, and real-time controls
remain future work.
