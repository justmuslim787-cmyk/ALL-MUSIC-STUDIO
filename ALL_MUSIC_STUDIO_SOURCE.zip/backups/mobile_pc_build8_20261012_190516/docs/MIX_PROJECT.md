# ALL MUSIC STUDIO — Mix Projects

MixProject stores a mix name, track paths, volume, pan, mute and solo
settings in a JSON project file.

Example:

    from app.audio.mix_project import MixProject

    project = MixProject("My Song")
    project.add_track("assets/music/track1.wav", volume=0.8)
    project.save("projects/my_song.mix.json")

    reopened = MixProject.load("projects/my_song.mix.json")
    result = reopened.render("assets/music/my_song_mix.wav")
    print(result)

Rendering currently supports compatible mono/stereo, uncompressed
16-bit PCM WAV files with matching sample rates. This build does not
provide a graphical interface or real-time playback mixing.
