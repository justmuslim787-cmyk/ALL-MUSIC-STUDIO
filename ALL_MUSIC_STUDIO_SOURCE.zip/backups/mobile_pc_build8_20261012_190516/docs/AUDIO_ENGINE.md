# ALL MUSIC STUDIO
/cd "$HOME/All-Music-Studio" || exit 1

mkdir -p app/audio tests docs backups logs

cat > app/audio/audio_engine.py <<'PY'
"""ALL MUSIC STUDIO - Audio Playback Engine."""

from pathlib import Path


SUPPORTED_FORMATS = {".wav", ".mp3", ".ogg", ".flac"}


class PygameAudioBackend:
    """Optional real audio playback backend."""

    def __init__(self):
        import pygame
        self.pygame = pygame
        if not pygame.mixer.get_init():
            pygame.mixer.init()

    def load(self, path):
        self.pygame.mixer.music.load(str(path))

    def play(self):
        self.pygame.mixer.music.play()

    def pause(self):
        self.pygame.mixer.music.pause()

    def resume(self):
        self.pygame.mixer.music.unpause()

    def stop(self):
        self.pygame.mixer.music.stop()

    def set_volume(self, volume):
        self.pygame.mixer.music.set_volume(volume)


class AudioEngine:
    """Load and control audio through a playback backend."""

    def __init__(self, backend=None):
        self.backend = backend
        self.file_path = None
        self.status = "idle"
        self.volume = 1.0
        self.last_error = None

        if self.backend is None:
            try:
                self.backend = PygameAudioBackend()
            except Exception as error:
                self.last_error = str(error)

    @property
    def available(self):
        return self.backend is not None

    def load_file(self, filename):
        path = Path(filename).expanduser()

        if not path.is_file():
            raise FileNotFoundError(f"Audio file not found: {path}")

        if path.suffix.lower() not in SUPPORTED_FORMATS:
            raise ValueError(
                "Unsupported audio format. Use WAV, MP3, OGG or FLAC."
            )

        if self.backend is None:
            raise RuntimeError(
                "Audio playback backend is unavailable. "
                "Install pygame in the environment where the studio runs."
            )

        self.backend.load(path)
        self.file_path = path.resolve()
        self.status = "loaded"
        return self.file_path

    def play(self):
        self._require_loaded()
        self.backend.play()
        self.status = "playing"

    def pause(self):
        self._require_loaded()
        if self.status == "playing":
            self.backend.pause()
            self.status = "paused"

    def resume(self):
        self._require_loaded()
        if self.status == "paused":
            self.backend.resume()
            self.status = "playing"
        elif self.status in {"loaded", "stopped"}:
            self.play()

    def stop(self):
        self._require_loaded()
        self.backend.stop()
        self.status = "stopped"

    def set_volume(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Volume must be a number.")

        if not 0.0 <= value <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0.")

        self.volume = float(value)

        if self.backend is not None:
            self.backend.set_volume(self.volume)

        return self.volume

    def _require_loaded(self):
        if self.file_path is None:
            raise RuntimeError("Load an audio file first.")

        if self.backend is None:
            raise RuntimeError(
                "Audio playback backend is unavailable."
            )

    def info(self):
        return {
            "file": str(self.file_path) if self.file_path else None,
            "status": self.status,
            "volume": self.volume,
            "playback_available": self.available,
        }
PY

cat > tests/test_audio_engine.py <<'PY'
"""Automated tests for ALL MUSIC STUDIO AudioEngine."""

import tempfile
import unittest
import wave
from pathlib import Path

from app.audio.audio_engine import AudioEngine


class FakeBackend:
    """Simulates playback so core controls can be tested without speakers."""

    def __init__(self):
        self.calls = []
        self.loaded_path = None
        self.volume = 1.0

    def load(self, path):
        self.loaded_path = Path(path)
        self.calls.append("load")

    def play(self):
        self.calls.append("play")

    def pause(self):
        self.calls.append("pause")

    def resume(self):
        self.calls.append("resume")

    def stop(self):
        self.calls.append("stop")

    def set_volume(self, volume):
        self.volume = volume
        self.calls.append("volume")


class AudioEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.wav_path = Path(self.temp_dir.name) / "test.wav"

        with wave.open(str(self.wav_path), "wb") as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(8000)
            audio.writeframes(b"\x00\x00" * 800)

        self.backend = FakeBackend()
        self.engine = AudioEngine(backend=self.backend)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_load_and_playback_controls(self):
        self.engine.load_file(self.wav_path)
        self.assertEqual(self.engine.status, "loaded")

        self.engine.play()
        self.assertEqual(self.engine.status, "playing")

        self.engine.pause()
        self.assertEqual(self.engine.status, "paused")

        self.engine.resume()
        self.assertEqual(self.engine.status, "playing")

        self.engine.stop()
        self.assertEqual(self.engine.status, "stopped")

        for action in ["load", "play", "pause", "resume", "stop"]:
            self.assertIn(action, self.backend.calls)

    def test_volume(self):
        self.engine.set_volume(0.5)
        self.assertEqual(self.engine.volume, 0.5)
        self.assertEqual(self.backend.volume, 0.5)

        with self.assertRaises(ValueError):
            self.engine.set_volume(2)

    def test_missing_file(self):
        missing = Path(self.temp_dir.name) / "missing.wav"
        with self.assertRaises(FileNotFoundError):
            self.engine.load_file(missing)

    def test_unsupported_format(self):
        bad_file = Path(self.temp_dir.name) / "file.txt"
        bad_file.write_text("test", encoding="utf-8")

        with self.assertRaises(ValueError):
            self.engine.load_file(bad_file)

    def test_play_before_load(self):
        with self.assertRaises(RuntimeError):
            self.engine.play()


if __name__ == "__main__":
    unittest.main(verbosity=2)
PY

cat > docs/AUDIO_ENGINE.md <<'DOC'
# ALL MUSIC STUDIO - Audio Engine

## Implemented
- Audio file loading interface
- Play, pause, resume and stop controls
- Volume control from 0.0 to 1.0
- WAV, MP3, OGG and FLAC file extensions
- Optional pygame playback backend
- Automated tests using a simulated backend

## Real playback
Real playback requires pygame and a working audio output device
in the environment where the studio runs.

The automated tests use a simulated backend. Passing those tests
does not prove that sound is coming from the device.

## Next development stage
Connect this engine to the graphical interface, then implement
independent playback channels for multiple tracks.
