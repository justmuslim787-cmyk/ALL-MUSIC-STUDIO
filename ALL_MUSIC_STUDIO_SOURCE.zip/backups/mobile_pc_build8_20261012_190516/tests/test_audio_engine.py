"""Automated tests for ALL MUSIC STUDIO AudioEngine."""

import tempfile
import unittest
import wave
from pathlib import Path

from app.audio.audio_engine import AudioEngine


class FakeBackend:
    """Simulates playback so core controls can be tested without speakers."""

    def __init__(self):
        self.calls = []
        self.loaded_path = None
        self.volume = 1.0

    def load(self, path):
        self.loaded_path = Path(path)
        self.calls.append("load")

    def play(self):
        self.calls.append("play")

    def pause(self):
        self.calls.append("pause")

    def resume(self):
        self.calls.append("resume")

    def stop(self):
        self.calls.append("stop")

    def set_volume(self, volume):
        self.volume = volume
        self.calls.append("volume")


class AudioEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.wav_path = Path(self.temp_dir.name) / "test.wav"

        with wave.open(str(self.wav_path), "wb") as audio:
            audio.setnchannels(1)
            audio.setsampwidth(2)
            audio.setframerate(8000)
            audio.writeframes(b"\x00\x00" * 800)

        self.backend = FakeBackend()
        self.engine = AudioEngine(backend=self.backend)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_load_and_playback_controls(self):
        self.engine.load_file(self.wav_path)
        self.assertEqual(self.engine.status, "loaded")

        self.engine.play()
        self.assertEqual(self.engine.status, "playing")

        self.engine.pause()
        self.assertEqual(self.engine.status, "paused")

        self.engine.resume()
        self.assertEqual(self.engine.status, "playing")

        self.engine.stop()
        self.assertEqual(self.engine.status, "stopped")

        for action in ["load", "play", "pause", "resume", "stop"]:
            self.assertIn(action, self.backend.calls)

    def test_volume(self):
        self.engine.set_volume(0.5)
        self.assertEqual(self.engine.volume, 0.5)
        self.assertEqual(self.backend.volume, 0.5)

        with self.assertRaises(ValueError):
            self.engine.set_volume(2)

    def test_missing_file(self):
        missing = Path(self.temp_dir.name) / "missing.wav"
        with self.assertRaises(FileNotFoundError):
            self.engine.load_file(missing)

    def test_unsupported_format(self):
        bad_file = Path(self.temp_dir.name) / "file.txt"
        bad_file.write_text("test", encoding="utf-8")

        with self.assertRaises(ValueError):
            self.engine.load_file(bad_file)

    def test_play_before_load(self):
        with self.assertRaises(RuntimeError):
            self.engine.play()


if __name__ == "__main__":
    unittest.main(verbosity=2)
