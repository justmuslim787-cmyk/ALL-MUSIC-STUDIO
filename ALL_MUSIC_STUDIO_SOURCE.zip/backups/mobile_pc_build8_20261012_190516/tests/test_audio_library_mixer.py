import tempfile
import unittest
import wave
from pathlib import Path

from app.audio.audio_library import AudioLibrary
from app.audio.mixer import AudioMixer


def make_wav(path):
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(22050)
        wav.writeframes(b"\x00\x00" * 100)


class AudioLibraryTests(unittest.TestCase):
    def test_scan_finds_wav(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            library = AudioLibrary(root / "library")
            make_wav(root / "test.wav")

            results = library.scan(folders=[root])

            self.assertTrue(
                any(item["name"] == "test.wav" for item in results)
            )

    def test_import_audio(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source.wav"
            make_wav(source)

            library = AudioLibrary(root / "library")
            imported = library.import_file(source)

            self.assertTrue(imported.is_file())
            self.assertEqual(imported.name, "source.wav")

    def test_reject_unsupported_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "notes.txt"
            source.write_text("not audio", encoding="utf-8")
            library = AudioLibrary(root / "library")

            with self.assertRaises(ValueError):
                library.import_file(source)

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            library = AudioLibrary(Path(tmp) / "library")

            with self.assertRaises(FileNotFoundError):
                library.import_file(Path(tmp) / "missing.wav")


class AudioMixerTests(unittest.TestCase):
    def test_independent_channel_values(self):
        mixer = AudioMixer()
        mixer.add_channel("1", "Music 1")
        mixer.add_channel("2", "Music 2")

        mixer.set_volume("1", 0.3)
        mixer.set_volume("2", 0.8)
        mixer.set_pan("1", -0.5)
        mixer.set_pan("2", 0.5)

        self.assertAlmostEqual(
            mixer.get_channel("1").volume, 0.3
        )
        self.assertAlmostEqual(
            mixer.get_channel("2").volume, 0.8
        )
        self.assertAlmostEqual(
            mixer.get_channel("1").pan, -0.5
        )
        self.assertAlmostEqual(
            mixer.get_channel("2").pan, 0.5
        )

    def test_mute_and_solo_logic(self):
        mixer = AudioMixer()
        mixer.add_channel("a", "Music A")
        mixer.add_channel("b", "Music B")

        mixer.set_solo("b", True)
        self.assertFalse(mixer.is_audible("a"))
        self.assertTrue(mixer.is_audible("b"))

        mixer.set_mute("b", True)
        self.assertFalse(mixer.is_audible("b"))

    def test_invalid_values(self):
        mixer = AudioMixer()
        mixer.add_channel("a")

        with self.assertRaises(ValueError):
            mixer.set_volume("a", 2)

        with self.assertRaises(ValueError):
            mixer.set_pan("a", -2)

    def test_remove_channel(self):
        mixer = AudioMixer()
        mixer.add_channel("a")
        self.assertTrue(mixer.remove_channel("a"))
        self.assertFalse(mixer.remove_channel("a"))


if __name__ == "__main__":
    unittest.main()
