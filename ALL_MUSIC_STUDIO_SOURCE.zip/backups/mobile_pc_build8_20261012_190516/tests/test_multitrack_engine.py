import os
import tempfile
import unittest
import wave

from app.audio.multitrack_engine import MultiTrackEngine


def make_wav(path, samples, rate=8000):
    with wave.open(path, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        import struct
        wav.writeframes(b"".join(struct.pack("<h", s) for s in samples))


def read_stereo(path):
    import struct
    with wave.open(path, "rb") as wav:
        self_info = (
            wav.getnchannels(),
            wav.getsampwidth(),
            wav.getframerate(),
            wav.getnframes(),
        )
        raw = wav.readframes(wav.getnframes())
    count = len(raw) // 2
    return self_info, struct.unpack("<" + "h" * count, raw)


class MultiTrackTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.a = os.path.join(self.tmp.name, "a.wav")
        self.b = os.path.join(self.tmp.name, "b.wav")
        self.out = os.path.join(self.tmp.name, "mix.wav")
        make_wav(self.a, [1000, 2000, 3000])
        make_wav(self.b, [500, 500, 500])
        self.engine = MultiTrackEngine()

    def test_mix_two_tracks(self):
        result = self.engine.render(
            [{"path": self.a}, {"path": self.b}], self.out
        )
        info, samples = read_stereo(self.out)
        self.assertEqual(info, (2, 2, 8000, 3))
        self.assertEqual(samples, (1500, 1500, 2500, 2500, 3500, 3500))
        self.assertEqual(result["active_tracks"], 2)

    def test_mute_track(self):
        self.engine.render(
            [{"path": self.a, "mute": True}, {"path": self.b}], self.out
        )
        _, samples = read_stereo(self.out)
        self.assertEqual(samples, (500, 500, 500, 500, 500, 500))

    def test_solo_track(self):
        self.engine.render(
            [{"path": self.a}, {"path": self.b, "solo": True}], self.out
        )
        _, samples = read_stereo(self.out)
        self.assertEqual(samples, (500, 500, 500, 500, 500, 500))

    def test_volume_zero(self):
        self.engine.render(
            [{"path": self.a, "volume": 0.0}], self.out
        )
        _, samples = read_stereo(self.out)
        self.assertEqual(samples, (0, 0, 0, 0, 0, 0))

    def test_invalid_volume(self):
        with self.assertRaises(ValueError):
            self.engine.render(
                [{"path": self.a, "volume": 2}], self.out
            )

    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            self.engine.render(
                [{"path": os.path.join(self.tmp.name, "missing.wav")}],
                self.out,
            )


if __name__ == "__main__":
    unittest.main()
