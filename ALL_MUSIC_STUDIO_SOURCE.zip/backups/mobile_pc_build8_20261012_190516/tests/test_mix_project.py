import json
import os
import tempfile
import unittest
import wave
import struct

from app.audio.mix_project import MixProject


class MixProjectTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.project_file = os.path.join(self.tmp.name, "test.mix.json")
        self.audio_file = os.path.join(self.tmp.name, "tone.wav")
        self.output_file = os.path.join(self.tmp.name, "render.wav")

        with wave.open(self.audio_file, "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(8000)
            wav.writeframes(struct.pack("<hhh", 1000, 2000, 3000))

    def test_save_and_load(self):
        project = MixProject("Test Song")
        project.add_track(self.audio_file, volume=0.7, pan=-0.2)
        project.save(self.project_file)

        loaded = MixProject.load(self.project_file)
        self.assertEqual(loaded.name, "Test Song")
        self.assertEqual(len(loaded.tracks), 1)
        self.assertAlmostEqual(loaded.tracks[0]["volume"], 0.7)
        self.assertAlmostEqual(loaded.tracks[0]["pan"], -0.2)

    def test_update_track(self):
        project = MixProject()
        project.add_track(self.audio_file)
        project.update_track(0, mute=True, volume=0.5)
        self.assertTrue(project.tracks[0]["mute"])
        self.assertEqual(project.tracks[0]["volume"], 0.5)

    def test_remove_track(self):
        project = MixProject()
        project.add_track(self.audio_file)
        project.remove_track(0)
        self.assertEqual(project.tracks, [])

    def test_invalid_volume(self):
        project = MixProject()
        with self.assertRaises(ValueError):
            project.add_track(self.audio_file, volume=1.5)

    def test_invalid_pan(self):
        project = MixProject()
        with self.assertRaises(ValueError):
            project.add_track(self.audio_file, pan=-2)

    def test_render_saved_project(self):
        project = MixProject("Render Test")
        project.add_track(self.audio_file)
        project.save(self.project_file)

        loaded = MixProject.load(self.project_file)
        result = loaded.render(self.output_file)

        self.assertTrue(os.path.isfile(self.output_file))
        self.assertEqual(result["tracks"], 1)
        with wave.open(self.output_file, "rb") as wav:
            self.assertEqual(wav.getnchannels(), 2)
            self.assertEqual(wav.getnframes(), 3)

    def test_reject_wrong_project_format(self):
        with open(self.project_file, "w", encoding="utf-8") as file:
            json.dump({"format": "other", "version": 1, "tracks": []}, file)

        with self.assertRaises(ValueError):
            MixProject.load(self.project_file)


if __name__ == "__main__":
    unittest.main()
