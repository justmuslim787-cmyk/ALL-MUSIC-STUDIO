"""Create, save, and load ALL MUSIC STUDIO project files."""

import json
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROJECTS_DIR = PROJECT_ROOT / "projects"
PROJECT_FORMAT_VERSION = 1


def create_project(name):
    """Create a new empty music project."""
    clean_name = name.strip()

    if not clean_name:
        raise ValueError("Project name cannot be empty.")

    return {
        "format_version": PROJECT_FORMAT_VERSION,
        "name": clean_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tracks": [],
        "tempo": 120,
        "time_signature": [4, 4],
    }


def save_project(project, filename=None):
    """Save a project as JSON inside the projects directory."""
    if not isinstance(project, dict):
        raise ValueError("Project must be a dictionary.")

    if project.get("format_version") != PROJECT_FORMAT_VERSION:
        raise ValueError("Unsupported project format version.")

    name = project.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Project name is invalid.")

    tempo = project.get("tempo")
    if not isinstance(tempo, int) or isinstance(tempo, bool):
        raise ValueError("Tempo must be an integer.")
    if not 20 <= tempo <= 300:
        raise ValueError("Tempo must be between 20 and 300 BPM.")

    if filename is None:
        filename = name

    filename = str(filename)
    if not filename.strip() or Path(filename).name != filename:
        raise ValueError("Filename must be a simple name, not a path.")

    if not filename.endswith(".json"):
        filename += ".json"

    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    destination = PROJECTS_DIR / filename
    temporary = destination.with_suffix(".json.tmp")

    try:
        temporary.write_text(
            json.dumps(project, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        temporary.replace(destination)
    finally:
        if temporary.exists():
            temporary.unlink()

    return destination


def load_project(filename):
    """Load and validate a saved project."""
    filename = str(filename)

    if not filename.strip() or Path(filename).name != filename:
        raise ValueError("Filename must be a simple name, not a path.")

    if not filename.endswith(".json"):
        filename += ".json"

    source = PROJECTS_DIR / filename
    project = json.loads(source.read_text(encoding="utf-8"))

    if not isinstance(project, dict):
        raise ValueError("Invalid project file.")

    if project.get("format_version") != PROJECT_FORMAT_VERSION:
        raise ValueError("Unsupported project format version.")

    if not isinstance(project.get("name"), str):
        raise ValueError("Project name is missing.")

    if not isinstance(project.get("tracks"), list):
        raise ValueError("Project tracks must be a list.")

    tempo = project.get("tempo")
    if not isinstance(tempo, int) or isinstance(tempo, bool):
        raise ValueError("Invalid project tempo.")
    if not 20 <= tempo <= 300:
        raise ValueError("Project tempo is out of range.")

    return project
