"""ALL MUSIC STUDIO - Master Build and Test System."""

import py_compile
import shutil
import sys
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKUPS = ROOT / "backups"
PROJECTS = ROOT / "projects"

REQUIRED = [
    "app/__init__.py",
    "app/audio/track.py",
    "app/audio/track_manager.py",
    "app/core/project_manager.py",
]

INTEGRATION = r'''

def save_studio_project(project, track_manager, filename=None):
    """Save project settings and all audio track data."""
    from app.audio.track_manager import TrackManager

    if not isinstance(track_manager, TrackManager):
        raise ValueError("Invalid track manager.")

    project["tracks"] = []

    for track in track_manager.list_tracks():
        project["tracks"].append({
            "track_id": track.track_id,
            "name": track.name,
            "track_type": track.track_type,
            "volume": track.volume,
            "pan": track.pan,
            "muted": track.muted,
            "solo": track.solo,
            "clips": track.clips,
        })

    return save_project(project, filename)


def load_studio_project(filename):
    """Load a project and restore its audio tracks."""
    from app.audio.track_manager import TrackManager

    project = load_project(filename)
    manager = TrackManager()

    for data in project["tracks"]:
        if not isinstance(data, dict):
            raise ValueError("Invalid track data.")

        track = manager.add_track(
            data.get("name", ""),
            data.get("track_type", "audio"),
        )

        track.set_volume(data.get("volume", 1.0))
        track.set_pan(data.get("pan", 0.0))

        muted = data.get("muted", False)
        solo = data.get("solo", False)
        clips = data.get("clips", [])

        if not isinstance(muted, bool) or not isinstance(solo, bool):
            raise ValueError("Invalid mute or solo value.")

        if not isinstance(clips, list) or not all(
            isinstance(clip, dict) for clip in clips
        ):
            raise ValueError("Invalid clip data.")

        track.muted = muted
        track.solo = solo
        track.clips = clips

        saved_id = data.get("track_id")
        if isinstance(saved_id, str) and saved_id:
            track.track_id = saved_id

    return project, manager
'''


def say(message):
    print(message, flush=True)


def ensure_files():
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise RuntimeError("Required files missing: " + ", ".join(missing))


def install_integration():
    path = ROOT / "app/core/project_manager.py"
    source = path.read_text(encoding="utf-8")

    has_save = "def save_studio_project(" in source
    has_load = "def load_studio_project(" in source

    if has_save and has_load:
        say("PASS: Project integration already exists.")
        return

    if has_save != has_load:
        raise RuntimeError(
            "Only part of the integration exists. "
            "File was not changed; inspect project_manager.py first."
        )

    BACKUPS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUPS / f"project_manager_{stamp}.py"
    shutil.copy2(path, backup)
    say(f"BACKUP: {backup.name}")

    path.write_text(
        source.rstrip() + "\n\n" + INTEGRATION.lstrip(),
        encoding="utf-8",
    )
    say("PASS: Project save/load integration added.")


def syntax_check():
    for relative in REQUIRED + ["app/diagnostics/health_check.py"]:
        path = ROOT / relative
        if path.is_file():
            py_compile.compile(str(path), doraise=True)
            say(f"PASS: Syntax - {relative}")


def functional_test():
    from app.audio.track_manager import TrackManager
    from app.core.project_manager import (
        create_project,
        save_studio_project,
        load_studio_project,
    )

    PROJECTS.mkdir(parents=True, exist_ok=True)
    test_name = "_master_build_test.json"
    test_path = PROJECTS / test_name

    if test_path.exists():
        raise RuntimeError(
            f"{test_name} already exists. Not overwriting user data."
        )

    try:
        manager = TrackManager()

        vocal = manager.add_track("Vocals")
        vocal.set_volume(0.75)
        vocal.set_pan(-0.25)
        vocal.muted = True
        vocal.clips = [{"position": 0, "duration": 4}]

        drums = manager.add_track("Drums", "instrument")

        assert manager.count() == 2
        assert manager.get_track(vocal.track_id) is vocal
        say("PASS: Track creation and lookup")

        project = create_project("Master Build Test")
        saved_path = save_studio_project(
            project, manager, "_master_build_test"
        )
        assert saved_path.is_file()
        say("PASS: Project and tracks saved")

        loaded_project, loaded_manager = load_studio_project(test_name)

        assert loaded_project["name"] == "Master Build Test"
        assert loaded_manager.count() == 2

        loaded_vocal = loaded_manager.list_tracks()[0]
        assert loaded_vocal.name == "Vocals"
        assert loaded_vocal.track_id == vocal.track_id
        assert loaded_vocal.volume == 0.75
        assert loaded_vocal.pan == -0.25
        assert loaded_vocal.muted is True
        assert loaded_vocal.clips == [{"position": 0, "duration": 4}]

        assert loaded_manager.list_tracks()[1].name == "Drums"
        say("PASS: Project and tracks restored correctly")

        removed = loaded_manager.remove_track(loaded_vocal.track_id)
        assert removed is not None
        assert loaded_manager.count() == 1
        say("PASS: Track removal")

    finally:
        if test_path.exists():
            test_path.unlink()
            say("CLEANUP: Temporary test project removed")


def main():
    say("=" * 44)
    say("ALL MUSIC STUDIO - MASTER BUILD")
    say("=" * 44)

    try:
        ensure_files()
        say("PASS: Required project files found")

        install_integration()
        syntax_check()
        functional_test()

        say("=" * 44)
        say("BUILD RESULT: PASSED")
        say("Project save/load and track tests succeeded.")
        say("This does not yet mean audio playback is implemented.")
        say("=" * 44)

    except Exception as error:
        say("=" * 44)
        say("BUILD RESULT: FAILED")
        say(f"{type(error).__name__}: {error}")
        say("Fix this error before adding more features.")
        say("=" * 44)
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
