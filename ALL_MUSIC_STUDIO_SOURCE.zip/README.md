# ALL MUSIC STUDIO

A modular music production application.

## Development
- Initial development: Android Termux
- Python: 3.13.13
- Desktop testing: Windows

## Planned Features
- Multitrack music timeline
- Beat sequencer and piano roll
- Audio mixing and effects
- Instrument management
- Project save and load
- WAV and MP3 export
- Future AI music generation

## Development Rules
- Test every feature.
- Diagnose errors before changing code.
- Do not download large models without checking compatibility.
- Preserve existing project files.
