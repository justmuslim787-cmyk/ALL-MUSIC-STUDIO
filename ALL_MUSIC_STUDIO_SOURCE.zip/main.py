from app.ui.studio_app import launch

if __name__ == '__main__':
    launch()
