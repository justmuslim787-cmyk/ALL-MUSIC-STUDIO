# Mobile + PC GUI Foundation

The Kivy-based interface is in `app/ui/studio_app.py`.

## Current features
- Responsive vertical layout suitable for narrow and wide windows.
- Lists supported audio files in `assets/music`.
- Selects an audio file.
- Provides initial transport, mixer and export controls.
- Imports files through the Python `import_audio_file()` API.

## Current limitations
- GUI import button does not yet open a native file picker.
- Play/Pause/Stop buttons are placeholders, not connected to live playback.
- The slider is currently a UI control, not wired to a playing track.
- Save Project and Export WAV buttons are placeholders; existing Python APIs
  can be used independently.
- No real-time multi-track playback is implemented by this GUI.
- Kivy must be installed in a compatible environment before launch.
- Android APK packaging and desktop packaging are separate build steps.

## Desktop launch
Install Kivy in the target desktop Python environment, then run:

    python -m app.ui.studio_app

Test the desktop GUI before packaging for Android.
