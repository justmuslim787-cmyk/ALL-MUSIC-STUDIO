"""Create, save, and load ALL MUSIC STUDIO project files."""

import json
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROJECTS_DIR = PROJECT_ROOT / "projects"
PROJECT_FORMAT_VERSION = 1


def create_project(name):
    """Create a new empty music project."""
    clean_name = name.strip()

    if not clean_name:
        raise ValueError("Project name cannot be empty.")

    return {
        "format_version": PROJECT_FORMAT_VERSION,
        "name": clean_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tracks": [],
        "tempo": 120,
        "time_signature": [4, 4],
    }


def save_project(project, filename=None):
    """Save a project as JSON inside the projects directory."""
    if not isinstance(project, dict):
        raise ValueError("Project must be a dictionary.")

    if project.get("format_version") != PROJECT_FORMAT_VERSION:
        raise ValueError("Unsupported project format version.")

    name = project.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Project name is invalid.")

    tempo = project.get("tempo")
    if not isinstance(tempo, int) or isinstance(tempo, bool):
        raise ValueError("Tempo must be an integer.")
    if not 20 <= tempo <= 300:
        raise ValueError("Tempo must be between 20 and 300 BPM.")

    if filename is None:
        filename = name

    filename = str(filename)
    if not filename.strip() or Path(filename).name != filename:
        raise ValueError("Filename must be a simple name, not a path.")

    if not filename.endswith(".json"):
        filename += ".json"

    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    destination = PROJECTS_DIR / filename
    temporary = destination.with_suffix(".json.tmp")

    try:
        temporary.write_text(
            json.dumps(project, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        temporary.replace(destination)
    finally:
        if temporary.exists():
            temporary.unlink()

    return destination


def load_project(filename):
    """Load and validate a saved project."""
    filename = str(filename)

    if not filename.strip() or Path(filename).name != filename:
        raise ValueError("Filename must be a simple name, not a path.")

    if not filename.endswith(".json"):
        filename += ".json"

    source = PROJECTS_DIR / filename
    project = json.loads(source.read_text(encoding="utf-8"))

    if not isinstance(project, dict):
        raise ValueError("Invalid project file.")

    if project.get("format_version") != PROJECT_FORMAT_VERSION:
        raise ValueError("Unsupported project format version.")

    if not isinstance(project.get("name"), str):
        raise ValueError("Project name is missing.")

    if not isinstance(project.get("tracks"), list):
        raise ValueError("Project tracks must be a list.")

    tempo = project.get("tempo")
    if not isinstance(tempo, int) or isinstance(tempo, bool):
        raise ValueError("Invalid project tempo.")
    if not 20 <= tempo <= 300:
        raise ValueError("Project tempo is out of range.")

    return project

def save_studio_project(project, track_manager, filename=None):
    """Save project settings and all audio track data."""
    from app.audio.track_manager import TrackManager

    if not isinstance(track_manager, TrackManager):
        raise ValueError("Invalid track manager.")

    project["tracks"] = []

    for track in track_manager.list_tracks():
        project["tracks"].append({
            "track_id": track.track_id,
            "name": track.name,
            "track_type": track.track_type,
            "volume": track.volume,
            "pan": track.pan,
            "muted": track.muted,
            "solo": track.solo,
            "clips": track.clips,
        })

    return save_project(project, filename)


def load_studio_project(filename):
    """Load a project and restore its audio tracks."""
    from app.audio.track_manager import TrackManager

    project = load_project(filename)
    manager = TrackManager()

    for data in project["tracks"]:
        if not isinstance(data, dict):
            raise ValueError("Invalid track data.")

        track = manager.add_track(
            data.get("name", ""),
            data.get("track_type", "audio"),
        )

        track.set_volume(data.get("volume", 1.0))
        track.set_pan(data.get("pan", 0.0))

        muted = data.get("muted", False)
        solo = data.get("solo", False)
        clips = data.get("clips", [])

        if not isinstance(muted, bool) or not isinstance(solo, bool):
            raise ValueError("Invalid mute or solo value.")

        if not isinstance(clips, list) or not all(
            isinstance(clip, dict) for clip in clips
        ):
            raise ValueError("Invalid clip data.")

        track.muted = muted
        track.solo = solo
        track.clips = clips

        saved_id = data.get("track_id")
        if isinstance(saved_id, str) and saved_id:
            track.track_id = saved_id

    return project, manager
