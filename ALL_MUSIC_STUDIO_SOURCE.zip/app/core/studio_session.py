"""Studio session connecting playback, library and mix projects."""

from pathlib import Path

from app.audio.audio_engine import AudioEngine
from app.audio.mix_project import MixProject

ROOT = Path(__file__).resolve().parents[2]
MUSIC_DIR = ROOT / "assets" / "music"
PROJECT_DIR = ROOT / "projects"
SUPPORTED = {".wav", ".mp3", ".ogg", ".flac"}


class StudioSession:
    """Testable application logic for the ALL MUSIC STUDIO interface."""

    def __init__(self, audio_engine=None, project=None):
        self.audio = audio_engine or AudioEngine()
        self.project = project or MixProject("My Mix")
        self.selected_file = None

        MUSIC_DIR.mkdir(parents=True, exist_ok=True)
        PROJECT_DIR.mkdir(parents=True, exist_ok=True)

    def library(self):
        """Return supported audio files in the studio music folder."""
        return sorted(
            (
                path for path in MUSIC_DIR.iterdir()
                if path.is_file() and path.suffix.lower() in SUPPORTED
            ),
            key=lambda path: path.name.lower(),
        )

    def select_file(self, filename):
        """Select and load a file into the single-file playback engine."""
        path = Path(filename).expanduser().resolve()

        if not path.is_file():
            raise FileNotFoundError(str(path))

        if path.suffix.lower() not in SUPPORTED:
            raise ValueError("Use WAV, MP3, OGG or FLAC files.")

        self.audio.load_file(str(path))
        self.selected_file = path
        return str(path)

    def play(self):
        self.audio.play()
        return self.audio.info()

    def pause(self):
        self.audio.pause()
        return self.audio.info()

    def resume(self):
        self.audio.resume()
        return self.audio.info()

    def stop(self):
        self.audio.stop()
        return self.audio.info()

    def set_volume(self, value):
        return self.audio.set_volume(value)

    def add_mix_track(self, filename, volume=1.0, pan=0.0,
                      mute=False, solo=False):
        return self.project.add_track(
            str(Path(filename).expanduser().resolve()),
            volume=volume,
            pan=pan,
            mute=mute,
            solo=solo,
        )

    def remove_mix_track(self, index):
        return self.project.remove_track(index)

    def update_mix_track(self, index, **settings):
        return self.project.update_track(index, **settings)

    def save_project(self, filename=None):
        if filename is None:
            filename = PROJECT_DIR / "my_mix.ams.json"
        return self.project.save(str(filename))

    def load_project(self, filename):
        self.project = MixProject.load(str(filename))
        return self.project.summary()

    def export_wav(self, filename=None):
        if filename is None:
            filename = ROOT / "exports" / "my_mix.wav"
        return self.project.render(str(filename))

    def status(self):
        return {
            "selected_file": (
                str(self.selected_file) if self.selected_file else None
            ),
            "audio": self.audio.info(),
            "project": self.project.summary(),
            "library_count": len(self.library()),
        }
