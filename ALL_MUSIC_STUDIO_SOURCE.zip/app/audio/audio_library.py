"""ALL MUSIC STUDIO: local audio library."""

from pathlib import Path
import shutil

SUPPORTED_FORMATS = {".wav", ".mp3", ".ogg", ".flac"}


class AudioLibrary:
    """Find, list, search and import supported audio files."""

    def __init__(self, library_dir="assets/music"):
        self.library_dir = Path(library_dir).expanduser()
        self.library_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def is_audio_file(path):
        path = Path(path)
        return (
            path.is_file()
            and path.suffix.lower() in SUPPORTED_FORMATS
        )

    def scan(self, folders=None, recursive=True):
        """Find audio files in the library and optional folders."""
        roots = [self.library_dir]

        if folders:
            roots.extend(Path(p).expanduser() for p in folders)

        found = {}
        for root in roots:
            if not root.is_dir():
                continue

            iterator = (
                root.rglob("*")
                if recursive
                else root.iterdir()
            )

            for path in iterator:
                try:
                    if self.is_audio_file(path):
                        resolved = path.resolve()
                        found[str(resolved)] = {
                            "name": path.name,
                            "path": str(resolved),
                            "format": path.suffix.lower().lstrip("."),
                            "size_bytes": path.stat().st_size,
                        }
                except (OSError, PermissionError):
                    continue

        return sorted(
            found.values(),
            key=lambda item: item["name"].casefold()
        )

    def search(self, query, folders=None):
        """Search audio filenames without case sensitivity."""
        query = str(query).strip().casefold()
        return [
            item for item in self.scan(folders=folders)
            if query in item["name"].casefold()
        ]

    def import_file(self, source):
        """Copy a supported audio file into the studio library."""
        source = Path(source).expanduser()

        if not source.is_file():
            raise FileNotFoundError(
                f"Audio file not found: {source}"
            )

        if source.suffix.lower() not in SUPPORTED_FORMATS:
            raise ValueError(
                "Unsupported format. Use WAV, MP3, OGG or FLAC."
            )

        source = source.resolve()

        # Avoid copying a file onto itself.
        try:
            if source.parent.resolve() == self.library_dir.resolve():
                if source.exists():
                    return source
        except OSError:
            pass

        destination = self.library_dir / source.name

        # Keep existing files safe: create a unique filename.
        if destination.exists() and destination.resolve() != source:
            stem = source.stem
            suffix = source.suffix
            number = 2

            while destination.exists():
                destination = (
                    self.library_dir / f"{stem}_{number}{suffix}"
                )
                number += 1

        if destination.resolve() != source:
            shutil.copy2(source, destination)

        return destination.resolve()

    def count(self):
        return len(self.scan())
