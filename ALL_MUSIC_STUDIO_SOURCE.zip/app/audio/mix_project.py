"""Save, load, validate and render ALL MUSIC STUDIO mix projects."""

import json
import os

from app.audio.multitrack_engine import MultiTrackEngine


class MixProject:
    VERSION = 1

    def __init__(self, name="My Mix"):
        self.name = str(name)
        self.tracks = []
        self.project_path = None

    def add_track(
        self,
        path,
        volume=1.0,
        pan=0.0,
        mute=False,
        solo=False,
    ):
        if not isinstance(path, str) or not path.strip():
            raise ValueError("Track path is required")

        volume = float(volume)
        pan = float(pan)

        if not 0.0 <= volume <= 1.0:
            raise ValueError("Volume must be between 0 and 1")
        if not -1.0 <= pan <= 1.0:
            raise ValueError("Pan must be between -1 and 1")

        track = {
            "path": os.path.abspath(os.path.expanduser(path)),
            "volume": volume,
            "pan": pan,
            "mute": bool(mute),
            "solo": bool(solo),
        }
        self.tracks.append(track)
        return track

    def remove_track(self, index):
        if not 0 <= index < len(self.tracks):
            raise IndexError("Track index out of range")
        return self.tracks.pop(index)

    def update_track(self, index, **settings):
        if not 0 <= index < len(self.tracks):
            raise IndexError("Track index out of range")

        allowed = {"volume", "pan", "mute", "solo"}
        unknown = set(settings) - allowed
        if unknown:
            raise ValueError("Unsupported settings: " + ", ".join(sorted(unknown)))

        track = self.tracks[index]
        candidate = dict(track)
        candidate.update(settings)

        candidate["volume"] = float(candidate["volume"])
        candidate["pan"] = float(candidate["pan"])

        if not 0.0 <= candidate["volume"] <= 1.0:
            raise ValueError("Volume must be between 0 and 1")
        if not -1.0 <= candidate["pan"] <= 1.0:
            raise ValueError("Pan must be between -1 and 1")

        track.update(candidate)
        return dict(track)

    def save(self, path):
        path = os.path.abspath(os.path.expanduser(path))
        parent = os.path.dirname(path)
        os.makedirs(parent or ".", exist_ok=True)

        data = {
            "format": "all_music_studio_mix",
            "version": self.VERSION,
            "name": self.name,
            "tracks": self.tracks,
        }

        temporary = path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=2, ensure_ascii=False)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.remove(temporary)

        self.project_path = path
        return path

    @classmethod
    def load(cls, path):
        path = os.path.abspath(os.path.expanduser(path))

        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)

        if not isinstance(data, dict):
            raise ValueError("Invalid project format")
        if data.get("format") != "all_music_studio_mix":
            raise ValueError("Not an ALL MUSIC STUDIO mix project")
        if data.get("version") != cls.VERSION:
            raise ValueError("Unsupported project version")
        if not isinstance(data.get("tracks"), list):
            raise ValueError("Project tracks must be a list")

        project = cls(data.get("name", "My Mix"))

        for track in data["tracks"]:
            if not isinstance(track, dict):
                raise ValueError("Invalid track entry")

            project.add_track(
                path=track.get("path", ""),
                volume=track.get("volume", 1.0),
                pan=track.get("pan", 0.0),
                mute=track.get("mute", False),
                solo=track.get("solo", False),
            )

        project.project_path = path
        return project

    def render(self, output_path):
        if not self.tracks:
            raise ValueError("Add at least one track before rendering")

        engine = MultiTrackEngine()
        return engine.render(self.tracks, output_path)

    def summary(self):
        return {
            "name": self.name,
            "track_count": len(self.tracks),
            "project_path": self.project_path,
            "tracks": [dict(track) for track in self.tracks],
        }
