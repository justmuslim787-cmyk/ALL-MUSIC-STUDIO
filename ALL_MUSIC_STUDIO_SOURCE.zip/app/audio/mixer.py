"""ALL MUSIC STUDIO: mixer channel control model.

This module stores mixer controls. Actual independent simultaneous
audio playback requires a multichannel-capable audio backend.
"""

from dataclasses import dataclass, asdict
from typing import Dict


@dataclass
class MixerChannel:
    channel_id: str
    name: str
    volume: float = 1.0
    pan: float = 0.0
    muted: bool = False
    solo: bool = False

    def __post_init__(self):
        self.set_volume(self.volume)
        self.set_pan(self.pan)

    def set_volume(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Volume must be a number from 0 to 1.")
        if not 0.0 <= float(value) <= 1.0:
            raise ValueError("Volume must be between 0 and 1.")
        self.volume = float(value)

    def set_pan(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Pan must be a number from -1 to 1.")
        if not -1.0 <= float(value) <= 1.0:
            raise ValueError("Pan must be between -1 and 1.")
        self.pan = float(value)

    def to_dict(self):
        return asdict(self)


class AudioMixer:
    """Manage independent logical mixer channels."""

    def __init__(self):
        self.channels: Dict[str, MixerChannel] = {}

    def add_channel(self, channel_id, name=None):
        channel_id = str(channel_id)

        if channel_id in self.channels:
            raise ValueError(f"Channel already exists: {channel_id}")

        channel = MixerChannel(
            channel_id=channel_id,
            name=name or channel_id,
        )
        self.channels[channel_id] = channel
        return channel

    def remove_channel(self, channel_id):
        if channel_id not in self.channels:
            return False
        del self.channels[channel_id]
        return True

    def get_channel(self, channel_id):
        try:
            return self.channels[channel_id]
        except KeyError as exc:
            raise KeyError(
                f"Unknown mixer channel: {channel_id}"
            ) from exc

    def set_volume(self, channel_id, value):
        channel = self.get_channel(channel_id)
        channel.set_volume(value)
        return channel.volume

    def set_pan(self, channel_id, value):
        channel = self.get_channel(channel_id)
        channel.set_pan(value)
        return channel.pan

    def set_mute(self, channel_id, enabled):
        if not isinstance(enabled, bool):
            raise ValueError("Mute state must be True or False.")
        self.get_channel(channel_id).muted = enabled

    def set_solo(self, channel_id, enabled):
        if not isinstance(enabled, bool):
            raise ValueError("Solo state must be True or False.")
        self.get_channel(channel_id).solo = enabled

    def is_audible(self, channel_id):
        """Calculate logical mute/solo status, not real sound output."""
        channel = self.get_channel(channel_id)

        if channel.muted:
            return False

        solo_channels = [
            c for c in self.channels.values() if c.solo
        ]

        if solo_channels:
            return channel.solo

        return True

    def list_channels(self):
        return [
            {
                **channel.to_dict(),
                "audible_by_mixer_state": self.is_audible(
                    channel.channel_id
                ),
            }
            for channel in self.channels.values()
        ]

    def export_state(self):
        return {
            "format_version": 1,
            "channels": self.list_channels(),
        }
