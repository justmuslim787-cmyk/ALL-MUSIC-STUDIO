"""Track management for ALL MUSIC STUDIO."""

from app.audio.track import AudioTrack


class TrackManager:
    def __init__(self):
        self._tracks = []

    def add_track(self, name, track_type="audio"):
        track = AudioTrack(name=name, track_type=track_type)
        self._tracks.append(track)
        return track

    def remove_track(self, track_id):
        for index, track in enumerate(self._tracks):
            if track.track_id == track_id:
                return self._tracks.pop(index)
        return None

    def get_track(self, track_id):
        for track in self._tracks:
            if track.track_id == track_id:
                return track
        return None

    def list_tracks(self):
        return list(self._tracks)

    def count(self):
        return len(self._tracks)

    def clear(self):
        self._tracks.clear()
