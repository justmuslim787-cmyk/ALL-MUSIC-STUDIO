"""ALL MUSIC STUDIO - Android and desktop audio engine."""

import shutil
import subprocess
from pathlib import Path

SUPPORTED_FORMATS = {".wav", ".mp3", ".ogg", ".flac"}


class TermuxMediaBackend:
    """Real playback through the Termux:API media player."""

    def __init__(self):
        if not shutil.which("termux-media-player"):
            raise RuntimeError("termux-media-player command not found.")
        self.file_path = None
        self.volume = 1.0

    def load(self, path):
        self.file_path = str(path)

    def _run(self, *args):
        try:
            result = subprocess.run(
                ["termux-media-player", *args],
                check=True,
                capture_output=True,
                text=True,
                timeout=20,
            )
            return result.stdout.strip()
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            details = getattr(exc, "stderr", "") or str(exc)
            raise RuntimeError(
                "Android media playback failed. Check that the "
                "Termux:API Android companion app is installed and "
                "matches your Termux installation. " + str(details)
            ) from exc

    def play(self):
        if not self.file_path:
            raise RuntimeError("Load an audio file first.")
        self._run("play", self.file_path)

    def pause(self):
        self._run("pause")

    def resume(self):
        self._run("resume")

    def stop(self):
        self._run("stop")

    def set_volume(self, volume):
        self.volume = volume
        raise NotImplementedError(
            "Termux media player does not expose per-track volume "
            "through this command. Mixer volume will be implemented "
            "using a suitable audio backend."
        )


class PygameAudioBackend:
    """Optional desktop playback backend."""

    def __init__(self):
        import pygame
        self.pygame = pygame
        if not pygame.mixer.get_init():
            pygame.mixer.init()

    def load(self, path):
        self.pygame.mixer.music.load(str(path))

    def play(self):
        self.pygame.mixer.music.play()

    def pause(self):
        self.pygame.mixer.music.pause()

    def resume(self):
        self.pygame.mixer.music.unpause()

    def stop(self):
        self.pygame.mixer.music.stop()

    def set_volume(self, volume):
        self.pygame.mixer.music.set_volume(volume)


class AudioEngine:
    """Audio file loading and playback controls."""

    def __init__(self, backend=None):
        self.backend = backend
        self.file_path = None
        self.status = "idle"
        self.volume = 1.0
        self.last_error = None
        self.backend_name = "custom" if backend else "unavailable"

        if self.backend is None:
            if shutil.which("termux-media-player"):
                try:
                    self.backend = TermuxMediaBackend()
                    self.backend_name = "Termux Android Media"
                except Exception as exc:
                    self.last_error = str(exc)

            if self.backend is None:
                try:
                    self.backend = PygameAudioBackend()
                    self.backend_name = "pygame"
                except Exception as exc:
                    self.last_error = str(exc)

    @property
    def available(self):
        return self.backend is not None

    def load_file(self, filename):
        path = Path(filename).expanduser()

        if not path.is_file():
            raise FileNotFoundError(f"Audio file not found: {path}")

        if path.suffix.lower() not in SUPPORTED_FORMATS:
            raise ValueError(
                "Unsupported format. Use WAV, MP3, OGG or FLAC."
            )

        if self.backend is None:
            raise RuntimeError(
                "No playback backend available. " +
                str(self.last_error or "Install a compatible audio backend.")
            )

        self.backend.load(path)
        self.file_path = path.resolve()
        self.status = "loaded"
        return self.file_path

    def play(self):
        self._require_loaded()
        self.backend.play()
        self.status = "playing"

    def pause(self):
        self._require_loaded()
        if self.status == "playing":
            self.backend.pause()
            self.status = "paused"

    def resume(self):
        self._require_loaded()
        if self.status == "paused":
            self.backend.resume()
            self.status = "playing"
        elif self.status in {"loaded", "stopped"}:
            self.play()

    def stop(self):
        self._require_loaded()
        self.backend.stop()
        self.status = "stopped"

    def set_volume(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Volume must be a number.")
        if not 0.0 <= value <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0.")

        if self.backend is not None:
            self.backend.set_volume(float(value))

        self.volume = float(value)
        return self.volume

    def _require_loaded(self):
        if self.file_path is None:
            raise RuntimeError("Load an audio file first.")
        if self.backend is None:
            raise RuntimeError("Audio playback backend is unavailable.")

    def info(self):
        return {
            "file": str(self.file_path) if self.file_path else None,
            "status": self.status,
            "volume": self.volume,
            "playback_available": self.available,
            "backend": self.backend_name,
            "error": self.last_error,
        }
