"""Basic audio track model for ALL MUSIC STUDIO."""

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass
class AudioTrack:
    name: str
    track_type: str = "audio"
    volume: float = 1.0
    pan: float = 0.0
    muted: bool = False
    solo: bool = False
    clips: list = field(default_factory=list)
    track_id: str = field(default_factory=lambda: str(uuid4()))

    def __post_init__(self):
        self.name = self.name.strip()

        if not self.name:
            raise ValueError("Track name cannot be empty.")

        if self.track_type not in {"audio", "midi", "instrument"}:
            raise ValueError("Unsupported track type.")

        self.set_volume(self.volume)
        self.set_pan(self.pan)

    def set_volume(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Volume must be a number.")

        if not 0.0 <= value <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0.")

        self.volume = float(value)

    def set_pan(self, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Pan must be a number.")

        if not -1.0 <= value <= 1.0:
            raise ValueError("Pan must be between -1.0 and 1.0.")

        self.pan = float(value)

    def add_clip(self, clip):
        if not isinstance(clip, dict):
            raise ValueError("Clip must be a dictionary.")

        self.clips.append(clip)
