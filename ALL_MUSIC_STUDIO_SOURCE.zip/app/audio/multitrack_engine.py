"""Basic offline multi-track WAV mixer using Python's standard library."""

import math
import os
import struct
import wave


class MultiTrackEngine:
    """Mix multiple mono/stereo, 16-bit PCM WAV files into one stereo WAV."""

    def __init__(self):
        self.last_output = None

    @staticmethod
    def _read_wav(path):
        if not os.path.isfile(path):
            raise FileNotFoundError(path)

        with wave.open(path, "rb") as wav:
            channels = wav.getnchannels()
            width = wav.getsampwidth()
            rate = wav.getframerate()
            frames = wav.getnframes()
            compression = wav.getcomptype()
            raw = wav.readframes(frames)

        if channels not in (1, 2):
            raise ValueError("Only mono and stereo WAV files are supported")
        if width != 2 or compression != "NONE":
            raise ValueError("Only uncompressed 16-bit PCM WAV files are supported")

        count = len(raw) // 2
        samples = struct.unpack("<" + "h" * count, raw) if count else ()

        stereo = []
        if channels == 1:
            for sample in samples:
                stereo.append((sample, sample))
        else:
            stereo = list(zip(samples[0::2], samples[1::2]))

        return rate, stereo

    def render(self, tracks, output_path):
        """
        tracks: list of dictionaries:
          {"path": "...wav", "volume": 1.0, "pan": 0.0,
           "mute": False, "solo": False}
        volume range 0..1; pan range -1..1.
        """
        if not tracks:
            raise ValueError("Add at least one track")

        prepared = []
        sample_rate = None

        for track in tracks:
            volume = float(track.get("volume", 1.0))
            pan = float(track.get("pan", 0.0))

            if not math.isfinite(volume) or not 0 <= volume <= 1:
                raise ValueError("Volume must be between 0 and 1")
            if not math.isfinite(pan) or not -1 <= pan <= 1:
                raise ValueError("Pan must be between -1 and 1")

            rate, samples = self._read_wav(track["path"])

            if sample_rate is None:
                sample_rate = rate
            elif rate != sample_rate:
                raise ValueError("All tracks must use the same sample rate")

            prepared.append({
                "samples": samples,
                "volume": volume,
                "pan": pan,
                "mute": bool(track.get("mute", False)),
                "solo": bool(track.get("solo", False)),
            })

        any_solo = any(t["solo"] and not t["mute"] for t in prepared)
        active = [
            t for t in prepared
            if not t["mute"] and (not any_solo or t["solo"])
        ]

        length = max((len(t["samples"]) for t in prepared), default=0)
        mixed = []

        for index in range(length):
            left = 0.0
            right = 0.0

            for track in active:
                samples = track["samples"]
                if index >= len(samples):
                    continue

                l_sample, r_sample = samples[index]
                volume = track["volume"]
                pan = track["pan"]

                left += l_sample * volume * min(1.0, 1.0 - pan)
                right += r_sample * volume * min(1.0, 1.0 + pan)

            left = max(-32768, min(32767, round(left)))
            right = max(-32768, min(32767, round(right)))
            mixed.append((left, right))

        output_path = os.path.abspath(output_path)
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        with wave.open(output_path, "wb") as wav:
            wav.setnchannels(2)
            wav.setsampwidth(2)
            wav.setframerate(sample_rate)
            wav.writeframes(b"".join(
                struct.pack("<hh", left, right)
                for left, right in mixed
            ))

        self.last_output = output_path
        return {
            "output": output_path,
            "sample_rate": sample_rate,
            "channels": 2,
            "frames": length,
            "duration_seconds": length / sample_rate if sample_rate else 0,
            "tracks": len(tracks),
            "active_tracks": len(active),
        }
