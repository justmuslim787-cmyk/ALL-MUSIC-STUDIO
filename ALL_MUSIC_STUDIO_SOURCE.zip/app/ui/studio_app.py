"""Functional Kivy interface for ALL MUSIC STUDIO."""

from pathlib import Path
import shutil

from app.core.studio_session import StudioSession

ROOT = Path(__file__).resolve().parents[2]
MUSIC_DIR = ROOT / "assets" / "music"
SUPPORTED = {".wav", ".mp3", ".ogg", ".flac"}


def list_audio_files():
    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(
        (p for p in MUSIC_DIR.iterdir()
         if p.is_file() and p.suffix.lower() in SUPPORTED),
        key=lambda p: p.name.lower(),
    )


def import_audio_file(source):
    source = Path(source).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(str(source))
    if source.suffix.lower() not in SUPPORTED:
        raise ValueError("Supported formats: WAV, MP3, OGG, FLAC")

    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    destination = MUSIC_DIR / source.name

    if source == destination.resolve():
        return destination

    stem, suffix = source.stem, source.suffix
    number = 2
    while destination.exists():
        destination = MUSIC_DIR / f"{stem}_{number}{suffix}"
        number += 1

    shutil.copy2(source, destination)
    return destination


def launch():
    try:
        from kivy.app import App
        from kivy.metrics import dp
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.button import Button
        from kivy.uix.label import Label
        from kivy.uix.popup import Popup
        from kivy.uix.scrollview import ScrollView
        from kivy.uix.slider import Slider
        from kivy.uix.textinput import TextInput
    except ImportError as exc:
        raise RuntimeError(
            "Kivy is not installed. Run this GUI in a supported "
            "Kivy desktop environment or packaged Android app."
        ) from exc

    class StudioApp(App):
        def build(self):
            self.title = "ALL MUSIC STUDIO"
            self.session = StudioSession()
            self.current_audio = None

            root = BoxLayout(
                orientation="vertical", padding=dp(10), spacing=dp(6)
            )

            root.add_widget(Label(
                text="[b]ALL MUSIC STUDIO[/b]",
                markup=True, font_size="23sp",
                size_hint_y=None, height=dp(42)
            ))
            root.add_widget(Label(
                text="MOBILE + PC  |  MUSIC LIBRARY + MIXER",
                size_hint_y=None, height=dp(26)
            ))

            self.status = Label(
                text="Ready — select a song",
                size_hint_y=None, height=dp(42)
            )
            root.add_widget(self.status)

            top = BoxLayout(
                size_hint_y=None, height=dp(44), spacing=dp(5)
            )
            self.add_button(top, "Import File", self.import_dialog)
            self.add_button(top, "Refresh", lambda *_: self.refresh_library())
            root.add_widget(top)

            self.library = BoxLayout(
                orientation="vertical", spacing=dp(4),
                size_hint_y=None
            )
            self.library.bind(
                minimum_height=self.library.setter("height")
            )
            scroll = ScrollView()
            scroll.add_widget(self.library)
            root.add_widget(scroll)

            root.add_widget(Label(
                text="[b]MASTER VOLUME[/b]",
                markup=True, size_hint_y=None, height=dp(28)
            ))

            self.volume = Slider(
                min=0, max=1, value=1,
                size_hint_y=None, height=dp(38)
            )
            self.volume.bind(value=self.change_volume)
            root.add_widget(self.volume)

            row1 = BoxLayout(
                size_hint_y=None, height=dp(46), spacing=dp(5)
            )
            for name, callback in (
                ("Play", self.play_audio),
                ("Pause", self.pause_audio),
                ("Resume", self.resume_audio),
                ("Stop", self.stop_audio),
            ):
                self.add_button(row1, name, callback)
            root.add_widget(row1)

            row2 = BoxLayout(
                size_hint_y=None, height=dp(46), spacing=dp(5)
            )
            for name, callback in (
                ("Add to Mix", self.add_to_mix),
                ("Save Project", self.save_project),
                ("Load Project", self.load_project_dialog),
                ("Export WAV", self.export_wav),
            ):
                self.add_button(row2, name, callback)
            root.add_widget(row2)

            self.refresh_library()
            return root

        def add_button(self, parent, text, callback):
            button = Button(text=text)
            button.bind(on_release=callback)
            parent.add_widget(button)
            return button

        def message(self, text):
            self.status.text = str(text)

        def run_action(self, callback):
            try:
                result = callback()
                self.message(result if result is not None else "Done")
            except Exception as exc:
                self.message(f"{type(exc).__name__}: {exc}")

        def refresh_library(self, *_):
            self.library.clear_widgets()
            files = list_audio_files()

            if not files:
                self.library.add_widget(Label(
                    text="No audio yet. Tap Import File to add a song.",
                    size_hint_y=None, height=dp(60)
                ))
                self.message("Library is empty")
                return

            for path in files:
                self.add_button(
                    self.library,
                    path.name,
                    lambda _btn, p=path: self.select_audio(p)
                ).size_hint_y = None
                self.library.children[0].height = dp(44)

            self.message(f"Library: {len(files)} audio file(s)")

        def select_audio(self, path):
            def action():
                self.session.select_file(path)
                self.current_audio = Path(path)
                return f"Selected: {self.current_audio.name}"
            self.run_action(action)

        def path_dialog(self, title, hint, callback):
            content = BoxLayout(
                orientation="vertical", padding=dp(8), spacing=dp(8)
            )
            field = TextInput(
                hint_text=hint, multiline=False, size_hint_y=None,
                height=dp(46)
            )
            content.add_widget(field)

            buttons = BoxLayout(
                size_hint_y=None, height=dp(44), spacing=dp(6)
            )
            popup = Popup(
                title=title, content=content,
                size_hint=(0.94, 0.38), auto_dismiss=True
            )

            def submit(*_):
                value = field.text.strip()
                if not value:
                    self.message("Enter a file path first")
                    return
                popup.dismiss()
                self.run_action(lambda: callback(value))

            self.add_button(buttons, "Continue", submit)
            self.add_button(buttons, "Cancel", lambda *_: popup.dismiss())
            content.add_widget(buttons)
            popup.open()

        def import_dialog(self, *_):
            def do_import(value):
                path = import_audio_file(value)
                self.refresh_library()
                return f"Imported: {path.name}"
            self.path_dialog(
                "Import Audio",
                "/full/path/to/song.mp3",
                do_import
            )

        def play_audio(self, *_):
            self.run_action(self.session.play)

        def pause_audio(self, *_):
            self.run_action(self.session.pause)

        def resume_audio(self, *_):
            self.run_action(self.session.resume)

        def stop_audio(self, *_):
            self.run_action(self.session.stop)

        def change_volume(self, _slider, value):
            try:
                self.session.set_volume(value)
                self.message(f"Volume: {round(value * 100)}%")
            except NotImplementedError:
                self.message(
                    "This audio backend does not support software volume."
                )
            except Exception as exc:
                self.message(f"Volume error: {exc}")

        def add_to_mix(self, *_):
            if not self.current_audio:
                self.message("Select a song first")
                return
            self.run_action(
                lambda: self.session.add_mix_track(self.current_audio)
            )

        def save_project(self, *_):
            self.path_dialog(
                "Save Mix Project",
                str(ROOT / "projects" / "my_mix.ams.json"),
                lambda path: f"Saved: {self.session.save_project(path)}"
            )

        def load_project_dialog(self, *_):
            self.path_dialog(
                "Load Mix Project",
                str(ROOT / "projects" / "my_mix.ams.json"),
                lambda path: f"Loaded: {self.session.load_project(path)}"
            )

        def export_wav(self, *_):
            self.path_dialog(
                "Export Mixed WAV",
                str(ROOT / "exports" / "my_mix.wav"),
                lambda path: f"Exported: {self.session.export_wav(path)}"
            )

    StudioApp().run()


if __name__ == "__main__":
    launch()
