"""All Music Studio cross-platform user interface."""
