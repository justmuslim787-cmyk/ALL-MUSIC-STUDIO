import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "app"

def main():
    print("ALL MUSIC STUDIO - HEALTH CHECK")
    print("Python:", sys.version.split()[0])
    print("Project:", ROOT)

    errors = []

    for path in sorted(APP.rglob("*.py")):
        try:
            ast.parse(path.read_text(encoding="utf-8"))
            print("OK:", path.relative_to(ROOT))
        except (SyntaxError, UnicodeError, OSError) as exc:
            errors.append((path, exc))
            print("ERROR:", path.relative_to(ROOT), exc)

    if errors:
        print("RESULT: FAILED")
        return 1

    print("RESULT: PASSED")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
