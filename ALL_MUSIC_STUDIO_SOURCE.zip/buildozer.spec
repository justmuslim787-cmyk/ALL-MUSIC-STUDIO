[app]
title = ALL MUSIC STUDIO
package.name = allmusicstudio
package.domain = org.allmusicstudio
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,wav,ogg,mp3,flac,json,md
version = 0.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 36
android.ndk = 29
p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 1
